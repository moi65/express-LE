function w(msg) {   console.log(msg); }

function _alert(msg) {  w(msg);}


$(document).ready(function () {
  'uses strict ';

  console.log("Version: %s", $.fn.jquery);
  
  $("#nina-beam").hide();

  //popin-invoke
   $("#popin-invoke").on("click", function(event) {
 
     $("#nina-beam").show(300);
     w( $('#log')[0].scrollHeight)  ;
   
     $("#popin-invoke").hide(1000)  ;
     $('#log').animate({scrollTop: $('#log')[0].scrollHeight}, 2000); 
    event.preventDefault();
  });
  
  $(":input").css("background-color", "#000");
  $("ul li").hide();
  
  jQuery('#input').on( "keyup", function() {
    // get the value from text field
    var input = jQuery(this).val();
    // by default every list element will be shown
    jQuery("ul li").show();
  
});
  

  
 
  
// highlight input fields on blur - This is what stops it working
$('#user_input').on('focusout', function(){
  $("#log").append("<p>user_input focusout</p>");
  
  $('#log').animate({ scrollTop: $('#log')[0].scrollHeight}, 2000);
})
  
  /* ========================================= */
  
   $(window).load(function() {

     $(".content").mCustomScrollbar();
     $.mCustomScrollbar.defaults.scrollButtons.enable=true; //enable scrolling buttons by default
     $(".content-rdsd").mCustomScrollbar({theme:"rounded-dots"}); //{theme:"3d-thick"});

      });
  
   $('#messagewindow').animate({
        scrollTop: $('#messagewindow')[0].scrollHeight}, 2000);
  
   $("#btn-2").on("click", function(event) {
       $('#messagewindow').animate({
        scrollTop: $('#messagewindow')[0].scrollHeight}, 2000);
       $('#log').animate({ scrollTop: $('#log')[0].scrollHeight}, 2000);
    });

}); // end $

/*

onclick="Nina.AgentLoader.loadAgent('nina-popin'); return false;"

*/
